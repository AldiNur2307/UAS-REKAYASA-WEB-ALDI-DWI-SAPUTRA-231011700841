<?php

namespace Faker\Provider\fr_CA;

class Color extends \Faker\Provider\fr_FR\Color
{
}
