

<?php $__env->startSection('content'); ?>
<div class="d-flex">
    <div class="bg-dark text-white p-3" style="width: 250px; min-height: 100vh;">
        <h3>Perpustakaan</h3>
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link text-white" href="#">Home</a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="#">Data Buku</a>
            </li>
        </ul>
    </div>

    <div class="container mt-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1>Data Buku Perpustakaan</h1>
            <div>
                <a href="<?php echo e(route('books.create')); ?>" class="btn btn-primary">Tambah Buku</a>
            </div>
        </div>

        <table class="table table-striped" id="books-table">
            <thead>
                <tr>
                    <th>ID Buku</th>
                    <th>Judul Buku</th>
                    <th>Penulis</th>
                    <th>Penerbit</th>
                    <th>Tahun Terbit</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($book->id_buku); ?></td>
                    <td><?php echo e($book->judul_buku); ?></td>
                    <td><?php echo e($book->penulis); ?></td>
                    <td><?php echo e($book->penerbit); ?></td>
                    <td><?php echo e($book->tahun_terbit); ?></td>
                    <td>
                        <a href="<?php echo e(route('books.edit', $book->id_buku)); ?>" class="btn btn-success btn-sm">Edit</a>
                        <form action="<?php echo e(route('books.destroy', $book->id_buku)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function () {
        $('#books-table').DataTable({
            dom: 'Bfrtip',
            buttons: ['excel', 'pdf', 'print']
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('books.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ACER\crud_uas\resources\views/books/index.blade.php ENDPATH**/ ?>