

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h1>Data Buku Perpustakaan</h1>
    <a href="<?php echo e(route('books.create')); ?>" class="btn btn-primary mb-2">Tambah Buku</a>
    <table class="table">
        <thead>
            <tr>
                <th>ID Buku</th>
                <th>Judul Buku</th>
                <th>Penulis</th>
                <th>Penerbit</th>
                <th>Tahun Terbit</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($book->id_buku); ?></td>
                <td><?php echo e($book->judul_buku); ?></td>
                <td><?php echo e($book->penulis); ?></td>
                <td><?php echo e($book->penerbit); ?></td>
                <td><?php echo e($book->tahun_terbit); ?></td>
                <td>
                    <a href="<?php echo e(route('books.edit', $book->id_buku)); ?>" class="btn btn-warning">Edit</a>
                    <form action="<?php echo e(route('books.destroy', $book->id_buku)); ?>" method="POST" style="display:inline;">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger">Hapus</button>
                </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('books.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ACER\crud_uas\resources\views\books\index.blade.php ENDPATH**/ ?>