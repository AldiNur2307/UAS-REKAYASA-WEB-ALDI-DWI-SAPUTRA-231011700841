<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\BookController;

// Route untuk tamu
Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'showLoginForm'])->name('login.form');
    Route::post('/login', [AuthController::class, 'login'])->name('login');
});

// Route untuk pengguna yang sudah login
// Route::middleware('auth')->group(function () {
    Route::get('/books', [BookController::class, 'index'])->name('books.index');

    Route::get('/books/create', [BookController::class, 'create'])->name('books.create');;
    Route::post('/books/store', [BookController::class, 'store'])->name('books.store');

    Route::get('books/{book}/edit', [BookController::class, 'edit'])->name('books.edit');
    Route::put('/books/update/{book}', [BookController::class, 'update'])->name('books.update');

    Route::delete('/books/destroy/{book}', [BookController::class, 'destroy'])->name('books.destroy');
    // Route::post('/logout', [AuthController::class, 'logout'])->name('logout');
// });