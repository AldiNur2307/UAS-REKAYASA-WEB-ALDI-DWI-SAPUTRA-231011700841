<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use App\Http\Requests\DataRequest;

class Controller extends BaseController
{
    public function exportPdf()
{
    $data = ModelName::all(); // Ambil data yang ingin dimasukkan
    $pdf = PDF::loadView('your-view-name', compact('data'));
    return $pdf->download('laporan.pdf');
}

public function store(DataRequest $request)
{
    // Validasi otomatis berjalan
    ModelName::create($request->validated());
}
}
